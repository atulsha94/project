'use strict'

var app = angular.module('myApp', []);


app.controller('myController',['$scope','TestPlanService',function($scope,TestPlanService) {
	$scope.testPlanModel= {testPlanId:null,testPlanTitle:'',testPlanDescription:'',testPlanStatus:'',testPlanType:''};
	$scope.testplans=[];
	
	fetchAllTestPlans();
	  
	    function fetchAllTestPlans(){
	    	alert('controller');
	        TestPlanService.fetchAllTestPlans()
	            .then(
	            function(d) {
	              $scope.users = d;
	            },
	            function(errResponse){
	                console.error('Error while fetching Users');
	            }
	        );
	    }
	    
	  $scope.createTestPlan= function()
	    {
		  TestPlanService.createTestPlan($scope.testPlanModel).then(fetchAllTestPlans,function(errorMsg){
	    		console.error('Failed to create');
	    	});
	    }
	
}])
