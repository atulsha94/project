/*package com.cybage.qualitymanagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriComponentsBuilder;

import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestCaseService;
import com.cybage.qualitymanagement.service.TestPlanService;

@RestController

public class TestPlanRestController {
	
	@Autowired
	TestPlanService testPlanService;
	@Autowired
	TestCaseService testCaseService;
	

	
	@RequestMapping(value = "/testPlan", method = RequestMethod.POST)

    public ResponseEntity<Void> createTestPlan(@RequestBody TestPlanModel testPlanModel,UriComponentsBuilder ucBuilder,
    		consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE) {
		System.out.println("in RESTTTTTTT");
		TestPlanModel validTestPlanModel = testPlanService.addTestPlan(testPlanModel);
  
        if (validTestPlanModel.getTestPlanId()== null) {
            System.out.println("A User with name " + testPlanModel.getTestPlanDescription() + " already exist");
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
  

  
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/testPlan/{testPlanId}").buildAndExpand(testPlanModel.getTestPlanId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
    }	

}
*/