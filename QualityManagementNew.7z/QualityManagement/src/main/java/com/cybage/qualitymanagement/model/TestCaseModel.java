package com.cybage.qualitymanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "testCases")
public class TestCaseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	Integer id;
	String title;
	String description;
	TestPlanModel testPlan;
	
	public TestCaseModel() {
	System.out.println("In test Case model constructor");	
	}

	public TestCaseModel(String title, String description, TestPlanModel testPlan) {
		super();
		this.title = title;
		this.description = description;
		this.testPlan=testPlan;
	}
	
	@Id
	@GeneratedValue
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	@Column(length = 30,unique = true)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	@Column(length = 30)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	@ManyToOne
	@JoinColumn(name = "testplan_id")
	public TestPlanModel getTestPlan() {
		return testPlan;
	}

	public void setTestPlan(TestPlanModel testPlan) {
		this.testPlan = testPlan;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestCaseModel other = (TestCaseModel) obj;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	
	@Override
	public String toString() {
		return "TestCaseModel [title=" + title 
				+ ", description=" + description 
				+ ",included in testPlan=" + testPlan.getTestPlanTitle() + "]";
	}
	
}
