package com.cybage.scriptmanagement.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.scriptmanagement.dao.TestScriptDao;
import com.cybage.scriptmanagement.dao.impl.TestScriptDaoImpl;
import com.cybage.scriptmanagement.model.TestScriptModel;
import com.cybage.scriptmanagement.service.TestScriptService;

@Service
@Transactional
public class TestScriptServiceImpl implements TestScriptService {

	@Autowired
	TestScriptDao testScriptDao;

	public TestScriptModel getTestScript(String testScriptId) {

		return testScriptDao.getTestScript(testScriptId);

	}

	public TestScriptModel insertIntoDb(TestScriptModel testScriptModel) {

		return testScriptDao.InsertIntoDB(testScriptModel);
	}

	public List<TestScriptModel> showAll() {

		List<TestScriptModel> testScriptList = testScriptDao.showAllTestCase();
		return testScriptList;

	}

	public TestScriptModel deleteTestScript(int testScriptId, TestScriptModel testScriptModel) {

		return testScriptDao.deleteTestScript(testScriptId, testScriptModel);

	}

	public TestScriptModel editTestScript(int testScriptId) {

		return testScriptDao.editTestScript(testScriptId);
	}

	public TestScriptModel updateIntoDB(TestScriptModel testScriptModel) {

		return testScriptDao.updateIntoDB(testScriptModel);

	}
}
