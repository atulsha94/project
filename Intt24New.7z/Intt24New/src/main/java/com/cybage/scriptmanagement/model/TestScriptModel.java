package com.cybage.scriptmanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TestScript")
public class TestScriptModel implements Serializable {

	private int test_script_id;
	private String test_script_title;
	private String test_script_description;
	private String test_script_execution_instruction;
	private String test_script_dataset;



	@Id
	@GeneratedValue
	@Column(name = "test_script_id", unique = true, nullable = false)
	public int getTest_script_id() {
		return test_script_id;
	}

	public void setTest_script_id(int test_script_id) {
		this.test_script_id = test_script_id;
	}

	@Column(name = "test_script_title")
	public String getTest_script_title() {
		return test_script_title;
	}

	public void setTest_script_title(String test_script_title) {
		this.test_script_title = test_script_title;
	}

	@Column(name = "test_script_description")
	public String getTest_script_description() {
		return test_script_description;
	}

	public void setTest_script_description(String test_script_description) {
		this.test_script_description = test_script_description;
	}

	@Column(name = "test_script_execution_instruction")
	public String getTest_script_execution_instruction() {
		return test_script_execution_instruction;
	}

	public void setTest_script_execution_instruction(String test_script_execution_instruction) {
		this.test_script_execution_instruction = test_script_execution_instruction;
	}

	@Column(name = "test_script_dataset")
	public String getTest_script_dataset() {
		return test_script_dataset;
	}

	public void setTest_script_dataset(String test_script_dataset) {
		this.test_script_dataset = test_script_dataset;
	}

}
