package com.cybage.scriptmanagement.dao.impl;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.scriptmanagement.dao.TestScriptDao;
import com.cybage.scriptmanagement.model.TestScriptModel;

@Repository
public class TestScriptDaoImpl implements TestScriptDao {
	
	@Autowired
	SessionFactory sf;
	
	/*Session session = HibernateUtil.getSessionFactory().openSession();
*/
	public TestScriptModel getTestScript(String testScriptId) {

/*		Session session = HibernateUtil.getSessionFactory().openSession();
*/
		Scanner sc = new Scanner(System.in);
/*		session.beginTransaction();
*/		TestScriptModel testModel = new TestScriptModel();

		Query query = sf.getCurrentSession().createQuery("from TestScriptModel");
		@SuppressWarnings("unchecked")
		List<TestScriptModel> empList = query.list();
		for (TestScriptModel emp : empList) {
			System.out
					.println("List of Employees::" + emp.getTest_script_id() + "," + emp.getTest_script_description());
		}
		return testModel;
	}

	public TestScriptModel InsertIntoDB(TestScriptModel testScriptModel) {
		// TODO Auto-generated method stub
/*		Session session = HibernateUtil.getSessionFactory().openSession();
*/		Scanner sc = new Scanner(System.in);
/*		session.beginTransaction();
*/		sf.getCurrentSession().save(testScriptModel);
/*		session.getTransaction().commit();
*/
		return testScriptModel;
	}

	public List<TestScriptModel> showAllTestCase() {

		
		@SuppressWarnings("unchecked")
		List<TestScriptModel> testScriptList = sf.getCurrentSession().createQuery("from TestScriptModel").list();

		return testScriptList;

	}

	public TestScriptModel deleteTestScript(int testScriptId, TestScriptModel testScriptModel) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		testScriptModel = (TestScriptModel) sf.getCurrentSession().load(TestScriptModel.class, new Integer(testScriptId));
		if (null != testScriptModel) {
			sf.getCurrentSession().delete(testScriptModel);
		}

		System.out.println("delete suceess..");
		

		return testScriptModel;
	}

	public TestScriptModel editTestScript(int testScriptId) {
		

		Criteria criteria = sf.getCurrentSession().createCriteria(TestScriptModel.class);

		criteria.add(Restrictions.eq("id", testScriptId));

		TestScriptModel testScriptModel = (TestScriptModel) criteria.uniqueResult();

		

		return testScriptModel;
	}

	public TestScriptModel updateIntoDB(TestScriptModel testScriptModel) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		sf.getCurrentSession().update(testScriptModel);


		return testScriptModel;
	}
}
