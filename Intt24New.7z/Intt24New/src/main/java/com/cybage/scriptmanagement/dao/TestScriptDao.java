package com.cybage.scriptmanagement.dao;

import java.util.List;

import com.cybage.scriptmanagement.model.TestScriptModel;

public interface TestScriptDao {

	TestScriptModel getTestScript(String testScriptId);

	TestScriptModel InsertIntoDB(TestScriptModel testScriptModel);

	List<TestScriptModel> showAllTestCase();

	TestScriptModel deleteTestScript(int testScriptId, TestScriptModel testScriptModel);

	TestScriptModel editTestScript(int testScriptId);

	TestScriptModel updateIntoDB(TestScriptModel testScriptModel);
}
