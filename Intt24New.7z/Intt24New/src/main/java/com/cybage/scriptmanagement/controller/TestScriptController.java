package com.cybage.scriptmanagement.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.scriptmanagement.model.TestScriptModel;
import com.cybage.scriptmanagement.service.TestScriptService;

@Controller
public class TestScriptController {
	@Autowired
	TestScriptService testScriptService;

	// To view add test script form
	@RequestMapping("/add")
	public ModelAndView showMessage1(@ModelAttribute("SpringWeb") TestScriptModel testScriptModel) {

		return new ModelAndView("addNewTestScript", "command", testScriptModel);
	}

	// insert new test script into database
	@RequestMapping("/insert")
	public ModelAndView addTestScript(@RequestParam(value = "id", required = false, defaultValue = "1") int id,
			HttpServletRequest request, ModelMap model, @ModelAttribute("SpringWeb") TestScriptModel testScriptModel) {

		TestScriptModel testScriptModel1 = testScriptService.insertIntoDb(testScriptModel);

		ModelMapper modelMapper = new ModelMapper();

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("allTestScripts");
	}

	// To view list of all test scripts(select query)
	@RequestMapping("/view")
	public ModelAndView showMessage2(@RequestParam(value = "id", required = false, defaultValue = "1") String id,
			HttpServletRequest request, ModelMap model) {

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("allTestScripts");

	}

	// delete test script
	@RequestMapping("/delete/{id}")
	public ModelAndView deleteTestScript(@PathVariable int id, HttpServletRequest request,
			@ModelAttribute("SpringWeb") TestScriptModel testScriptModel) {

		TestScriptModel testScriptModel1 = testScriptService.deleteTestScript(id, testScriptModel);

		return new ModelAndView("redirect:/view");
	}

	// fetch clicked test script into view from database
	@RequestMapping("/edit/{id}")
	public ModelAndView editTestScript(@PathVariable int id, HttpServletRequest request) {

		TestScriptModel testScriptModel = testScriptService.editTestScript(id);

		return new ModelAndView("editTestScript", "command", testScriptModel);
	}

	// update the particular record into database
	@RequestMapping(value = "/edit/updateTestScript", method = RequestMethod.POST)
	public ModelAndView addStudent(@ModelAttribute("SpringWeb") TestScriptModel testScriptModel, ModelMap model) {

		TestScriptModel tm1 = testScriptService.updateIntoDB(testScriptModel);

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("redirect:/view");
	}

}