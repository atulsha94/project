package com.cybage.qualitymanagement.service.impl;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.qualitymanagement.dao.TestCaseDao;
import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.dao.impl.TestCaseDaoImpl;
import com.cybage.qualitymanagement.model.TestCaseModel;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestCaseService;



@Service
@Transactional
public class TestCaseServiceImpl implements TestCaseService {

	@Autowired
	TestCaseDao testCaseDao;
	
	@Autowired
	TestPlanDao testPlanDao;
	
	@Override
	public ArrayList<String> getTestPlanTitles() {

		return testCaseDao.getTestPlanTitles();
	}
	
	@Override
	public TestCaseModel addTestCase(TestCaseModel testCaseModel,String testPlanTitle) {
		System.out.println("in testcase service");
		TestPlanModel testPlanModel=testPlanDao.getTestPlanByTitle(testPlanTitle);
		return testCaseDao.addTestCase(testCaseModel,testPlanModel);
	}

	
}
